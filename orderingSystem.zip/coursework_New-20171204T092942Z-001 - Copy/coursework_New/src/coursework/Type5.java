/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

/**
 *
 * @author up811216
 */
public class Type5 extends Type4{
    
    private boolean reInforcement = true; 
    public Type5(double  Length, double OuterDiameter, int Qantity, boolean isChemicalResist, int GradeValue, Order ord){
        super(Length, OuterDiameter, Qantity, isChemicalResist, GradeValue, ord);
        for(int i= 3; i<=5; i++){
            grade[i-3] = i;
        }
        calculatePipeCost();
    }
    
    
    public boolean getReinforcement(){
        return reInforcement; 
    }
    
    public String getPipeInfoSimplified(){
      String info = String.format("Pipe grade: %d, Length: %4.2f, Outer diameter: %4.1f, Qantity: %d, Chemical resistance: %s, Colours: %d, Insulated: Yes, Reinforced: Yes", gradeValue, length, outerDiameter, qantity, resist, noCols);
        return info ;
    }
    
    
    public void calculatePipeCost(){
        
        if(gradeValue==3){
         pipeCost = Double.parseDouble(df.format((volume*order.getGrade3Cost())*((order.getColNo2Cost()+order.getInsulationCost()+order.getReinforcedCost())+1)))*qantity;
        }
        else if (gradeValue==4){
           pipeCost = Double.parseDouble(df.format((volume*order.getGrade4Cost())*((order.getColNo2Cost()+order.getInsulationCost()+order.getReinforcedCost())+1)))*qantity;
        }
        else if (gradeValue==5){
            pipeCost = Double.parseDouble(df.format((volume*order.getGrade5Cost())*((order.getColNo2Cost()+order.getInsulationCost()+order.getReinforcedCost())+1)))*qantity;
        }
       
      System.out.println("Volume: " + volume); 
    if(chemicalResist){
            double temp = pipeCost; 
            pipeCost = pipeCost+((temp*(order.getResistCost()+1))-temp);
        }
        
    }
    
    
}
