import java.awt.*;

/**
 * Class to demonstrate functionality of the Pinball machine
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Demo
{
    private Machine machine;

    /**
     * Constructor for objects of class Demo
     */
    public Demo()
    {
        machine = new Machine();
    }

    /**
     * Sample demo method - demonstrates what happens when an object rebounds off the left-hand wall
     */
    public void sampleDemo()
    {
        // sample demo
        machine.resetMachine();
        
        PinballObject obj1 = new PinballObject(50, 200, 10, 2, Color.RED, 10, machine);
        PinballObject obj2 = new PinballObject(200, 200, -5, 6, Color.BLUE, 55, machine);
        PinballObject obj3 = new PinballObject(450, 125, -1, -1, Color.YELLOW, 40, machine);
        PinballObject obj4 = new PinballObject(100, 200, 2, -2, Color.MAGENTA, 25, machine);
        Circle hole = new Circle(150, 100, 2, -2, Color.BLACK, 25, machine);

        
        for(int i = 0; i <= 240; i++)
        {
            machine.pauseMachine();           // small delay
            obj1.move();
            machine.pauseMachine();
            machine.pauseMachine();
            machine.pauseMachine();
            machine.pauseMachine();
           
            
        }
    }
}
