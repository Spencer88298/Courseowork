

/**
 * Write a description of class Demo2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*; 
import java.awt.*; 


public class Demo2
{
    // instance variables - replace the example below with your own
    private int x;
    private ArrayList<PinballObject> Pinballs;  
    private Machine machine;
    private Circle hole;
    private Circle bumper; 

    /**
     * Constructor for objects of class Demo2
     */
    public Demo2()
    {
        // initialise instance variables
        Pinballs = new ArrayList<PinballObject>();
        machine = new Machine(); 
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void addBalls()
    {
        // put your code here

        PinballObject obj1 = new PinballObject(50, 250, 20, 6, Color.RED, 10, machine);
        PinballObject obj2 = new PinballObject(200, 200, -5, 6, Color.BLUE, 55, machine);
        PinballObject obj3 = new PinballObject(450, 125, -1, -1, Color.YELLOW, 40, machine);
        PinballObject obj4 = new PinballObject(100, 200, 2, -2, Color.MAGENTA, 25, machine);
        hole = new Circle(100, 200, 2, -2, Color.BLACK, 25, machine);
        bumper = new Circle(50, 250, 2, -2, Color.BLACK, 25, machine);
        
        Pinballs.add(obj1); 
        Pinballs.add(obj2);
        Pinballs.add(obj3); 
        Pinballs.add(obj4); 
    }
    
      public void drawBoard()
    {
        // put your code here
        boolean isComplete = false; 
         machine.resetMachine(); 
         hole.drawHoleBumper(); 
         bumper.drawHoleBumper();
         int x = 0; 
         while (x<=250){
         for (PinballObject i : Pinballs){
             machine.pauseMachine();
             i.move(); 
                }
             x++; 
            }
        }
    
}
