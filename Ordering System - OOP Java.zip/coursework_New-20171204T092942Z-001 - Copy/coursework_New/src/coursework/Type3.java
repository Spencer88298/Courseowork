/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

/**
 *
 * @author up811216
 */
public class Type3 extends Type1 {
    
    protected int noCols = 2; 
    
    public Type3(double  Length, double OuterDiameter, int Qantity, boolean isChemicalResist, int GradeValue, Order ord){
        super(Length, OuterDiameter, Qantity, isChemicalResist, GradeValue, ord);
        for(int i= 2; i<=5; i++){
            grade[i-2] = i;
        }
        calculatePipeCost();
    }
    
    public int getNoCols(){
        return noCols;
    }
    
    public String getPipeInfoSimplified(){
      String info = String.format("Pipe grade: %d, Length: %4.2f, Outer diameter: %4.1f, Qantity: %d, Chemical resistance: %s, Colours: %d", gradeValue, length, outerDiameter, qantity, resist, noCols);
        return info ;
    }
    
    public void calculatePipeCost(){
        if(gradeValue==2){
         pipeCost = Double.parseDouble(df.format((volume*order.getGrade2Cost())*(order.getColNo2Cost()+1)))*qantity;
        }
        else if (gradeValue==3){
            pipeCost = Double.parseDouble(df.format((volume*order.getGrade3Cost())*(order.getColNo2Cost()+1)))*qantity;
        }
        else if (gradeValue==4){
            pipeCost = Double.parseDouble(df.format((volume*order.getGrade4Cost())*(order.getColNo2Cost()+1)))*qantity;
        }
        else if(gradeValue == 5){
            pipeCost = Double.parseDouble(df.format((volume*order.getGrade5Cost())*(order.getColNo2Cost()+1)))*qantity;
    }
        
        if(chemicalResist){
            double temp = pipeCost; 
            pipeCost = pipeCost+((temp*(order.getResistCost()+1))-temp);
        }
        
    }
    
   
    
    
    
    
    
}
