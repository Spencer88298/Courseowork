/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

/**
 *
 * @author up811216
 */
public class Type1 extends Pipe{
    
    public Type1(double  Length, double OuterDiameter, int Qantity, boolean isChemicalResist, int GradeValue, Order ord){
        super(Length, OuterDiameter, Qantity, isChemicalResist, GradeValue, ord);
        for(int i= 1; i<=3; i++){
            grade[i] = i;
        }
        
    }
    
    public double getPipeCost(){
        return pipeCost;
    }
    
    public String getPipeInfoSimplified(){
      String info = String.format("Pipe grade: %d, Length: %4.3f, Outer diameter: %4.1f, Qantity: %d, Chemical resistance: %s, Colours: No", gradeValue, length, outerDiameter, qantity, resist); 
        return info ;
    }
    
     public double getLength(){
        return length;
    }
    
    public double getOuterDiameter(){
        return outerDiameter;
    }
    
    public double getVolume(){
        return volume;
    }
    
    public double getQantity(){
        return qantity;
    }
    
    public boolean getChemicalResist(){
        return chemicalResist;
    }
    
   
    
     public String getPipeCostStr(){
         String cost = String.format(df.format(pipeCost));
        return cost; 
     }
  
    
     public void setLength(double Length){
        length =  Length;
    }
   
    
    public void setOuterDiameter(double OuterDiameter){
         outerDiameter = OuterDiameter;
    }
    
    
    public void setQantity(int Qantity){
        qantity = Qantity;
    }
    
    public void setChemicalResist(boolean ChemicalResist){
        chemicalResist = chemicalResist;
    }
    
    public void CalculateVolume(){
        volume = (Math.PI*(Math.pow(((outerDiameter)/2), 2))*(length*order.getLengthInches())) -innerDiameterVolume;
        
    }
    
    public void CalculateInnerDiamaterVolume(){
        innerDiameterVolume = Math.PI*((Math.pow(((innerDiameter)/2), 2))*(length*order.getLengthInches()));
    }
    
    
    public void calculatePipeCost(){ 
        System.out.println(volume);
        if(gradeValue==1){
        pipeCost =  Double.parseDouble(df.format(volume*(order.getGrade1Cost())))*qantity;
        }else if(gradeValue==2){
            pipeCost = Double.parseDouble(df.format(volume*(order.getGrade2Cost())))*qantity;
        }
        else{
            pipeCost = Double.parseDouble(df.format(volume*(order.getGrade3Cost())))*qantity;
        }
        if(chemicalResist){
           
            pipeCost = (pipeCost*(order.getResistCost()+1));
        }
    }
    
}
