/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.util.ArrayList;

/**
 *
 * @author up811216
 */
public class OrderManage {
    private int ID;
    private ArrayList<Order> orderList = new ArrayList<Order>();
    private double totalOrderCost=0; 
    
    public OrderManage(int id){
        ID = id;
    }
    
    public void createOrder(Order ord){
        orderList.add(ord); 
    }
    
    public void RemoveOrder(int index){
        orderList.remove(index); 
    }
    
    /**
     * 
     * @param index
     * @return 
     */
    public Order getOrder(int index){
        return orderList.get(index);
    }
    public int getOrderListSize(){
        return orderList.size();
    }
    
    public String getOrderTotalCost(){
         double temp=0; 
            for (Order i : orderList){
               temp += Double.parseDouble(i.getOrderCost());
              totalOrderCost = temp;
         } 

          return String.format("%4.2f", totalOrderCost); 
      }
    
    public ArrayList<Order> getOrder(){
        return orderList; 
    }
}
