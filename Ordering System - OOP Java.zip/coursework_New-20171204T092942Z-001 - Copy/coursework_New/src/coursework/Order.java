/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;
import java.util.*; 
/**
 *
 * @author up811216
 */
public class Order {
    
    private ArrayList<Pipe> itemList = new ArrayList<Pipe>();
    private double volumeTotalCost = 0; 
    private double totalCost = 0; 
    private double orderCost = 0; 
    private double colNo1Cost = 0.12;
    private double colNo2Cost = 0.16;
    private double insulationCost = 0.13;
    private double resistCost = 0.14;
    private double reinforcedCost = 0.17;
    private double grade1Cost = 0.4;
    private double grade2Cost = 0.6;
    private double grade3Cost = 0.75;
    private double grade4Cost = 0.8;
    private double grade5Cost = 0.95;
    private double lengthInches = 39.37;
    private double lengthDiameter = 0.0254;
    private int ID;
    
    
    public Order(int id){
        ID = id; 
 
    }
    
    public ArrayList<Pipe> getPipeList(){
        return itemList; 
    }
    
    public int getPipeItemListSize(){
        return itemList.size();
    }
    
    public int getID(){
        return ID;
    }
    public double getColNo1Cost(){
        return colNo1Cost; 
    }
    
    public double getColNo2Cost(){
        return colNo2Cost; 
    }
    
    public void changeID(int id){
        ID = id; 
    }
    
    public double getInsulationCost(){
        return insulationCost; 
    }
    
    public double getResistCost(){
        return resistCost; 
    }
    
    public double getReinforcedCost(){
        return reinforcedCost; 
    }
    
    public double getGrade1Cost(){
        return grade1Cost; 
    }
    
     public double getGrade2Cost(){
        return grade2Cost; 
    }
     
      public double getGrade3Cost(){
        return grade3Cost; 
    }
      
       public double getGrade4Cost(){
        return grade4Cost; 
    }
       
        public double getGrade5Cost(){
        return grade5Cost; 
    }
     
     public double getVolumeTotal(){
        return volumeTotalCost; 
    } 
     
     public double getLengthInches(){
         return lengthInches;
     }
     
     public double getLengthDiameter(){
         return lengthDiameter;
     }
     
     public double getTotalCost(){
         return totalCost; 
     }
     
     public void calculateTotal(){
        for(Pipe i : itemList){
            totalCost += i.getPipeCost();
        }
    } 
     
     public void calculateVolumeTotal(){
         for(Pipe i : itemList){
            totalCost += i.getVolume();
        }
     }
         
     public void addPipe(Pipe p){
         itemList.add(p);
     }
     
     //Incomplete, needs to be indexes
      public void removePipe(Pipe p){
         itemList.remove(p);
     }
      //Add in functionality for String list i.e. each PipeInfoSimplifed is added to thr string list
      public void getPipeInfoSimple(){
          for (Pipe p : itemList){
              p.getPipeInfoSimplified();
          }
      }
      
     public String getOrderCost(){
         double temp=0; 
         if(itemList.size()>=1){
          for (Pipe i : itemList){
               temp += i.getPipeCost();
              orderCost = temp;
         } 
         }
         else{
             orderCost = 0; 
         }
          return String.format("%4.2f", orderCost); 
      }
     
   
        
      
}
