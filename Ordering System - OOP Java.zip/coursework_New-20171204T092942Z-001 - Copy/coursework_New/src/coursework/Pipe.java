/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;
import java.text.DecimalFormat;
import java.util.*; 
/**
 *
 * @author up811216
 */
public abstract class Pipe {
    
protected double length = 0;
protected double outerDiameter = 0;
protected double volume = 0;
protected int qantity = 0; 
protected int[] grade =  new int[4]; 
protected boolean chemicalResist = false; 
protected Order order;
protected double pipeCost = 0; 
protected double innerDiameter = 0; 
protected double innerDiameterVolume = 0; 
protected int gradeValue;
protected double standardCost = 0; 
protected  String resist; 
protected double baseCost=0; 
protected DecimalFormat df = new DecimalFormat("#.00");
    public Pipe(double  Length, double OuterDiameter, int Qantity, boolean isChemicalResist, int GradeValue, Order ord){
        for(int i= 1; i<=3; i++){
            grade[i-1] = i;
        }
        length = Length;
        outerDiameter = OuterDiameter;
        qantity = Qantity;
        chemicalResist = isChemicalResist; 
        innerDiameter = 0.9*outerDiameter; 
        order = ord; 
        gradeValue = GradeValue; 
        CalculateInnerDiamaterVolume();
        CalculateVolume();
        standardCost = volume*order.getGrade1Cost();
        calculatePipeCost();
       if(chemicalResist){
            resist = "Yes";
       }
       else{
           resist = "No";
       }
                
    }
    
    abstract double getLength();
    
    abstract double getOuterDiameter();
    
    abstract double getVolume();
    
    abstract double getQantity();
    
    abstract boolean getChemicalResist();
    
    abstract double getPipeCost();
    
     abstract String getPipeCostStr();
    
     abstract void setLength(double Length);
    
    abstract void setOuterDiameter(double OuterDiameter);
    
    
    abstract void setQantity(int Qantity);
    
    abstract void setChemicalResist(boolean ChemicalResist);
    
    abstract void CalculateVolume();
    
    abstract void CalculateInnerDiamaterVolume();
    
   abstract String getPipeInfoSimplified();
   
    
    abstract void calculatePipeCost();
  
    
}
