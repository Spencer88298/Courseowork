/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author up811216
 */
public class main {

    /**
     * @param args the command line arguments
     */
    
    public void runInteface(Interface c){
         SwingUtilities.invokeLater(new Runnable() {
            public void run() {
        c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c.setResizable(false);
        c.setVisible(true);
            }
        });
    }
    
    public void runReceipt(Receipt c){
         SwingUtilities.invokeLater(new Runnable() {
            public void run() {
        c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c.setResizable(false);
        c.setVisible(false);
            }
        });
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
      
        main d = new main();
        OrderManage manag = new OrderManage(1);
        Receipt e = new Receipt(manag);
        Interface c = new Interface(d, manag, e);
         d.runInteface(c);
         d.runReceipt(e);
         
         
         
         
    }
    
    
    
}
